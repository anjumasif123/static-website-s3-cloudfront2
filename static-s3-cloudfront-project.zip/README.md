# 🌐 Anjum's Portfolio — Hosted on AWS S3 + CloudFront

A personal portfolio website for **Anjum** (AWS Cloud Practitioner | Aspiring Cloud Support Engineer, based in Dubai, UAE) — built with HTML/CSS and deployed as a static website on Amazon S3, distributed globally via Amazon CloudFront CDN.

🔗 **Live Demo:** [https://d2wrsh5icek6ta.cloudfront.net](https://d2wrsh5icek6ta.cloudfront.net)

---

## 🏗️ Architecture

```
User Browser
     │
     ▼
┌──────────────────────────┐
│   Amazon CloudFront       │  ◄── Global CDN (HTTPS, fast delivery)
│   d2wrsh5icek6ta.net     │
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────┐
│   Amazon S3 Bucket        │  ◄── Static files (HTML, CSS)
│   anjum-portfolio-2026   │
└──────────────────────────┘
```

**How it works:**
1. Portfolio files (`index.html`, `style.css`, `error.html`) are stored in an S3 bucket
2. CloudFront sits in front as a CDN, caching content at edge locations worldwide
3. Users get fast, HTTPS-secured responses from the nearest CloudFront edge location

---

## ✨ Features

- ⚡ Fast global delivery via CloudFront edge locations
- 🔒 HTTPS enabled by default
- 💰 Free plan on CloudFront
- 🌍 Highly available and scalable
- 📄 Custom error page support

---

## 📁 Project Structure

```
aws-static-website/
├── index.html        # Main portfolio page
├── error.html        # Custom 404 error page
└── style.css         # Stylesheet
```

---

## 🛠️ Step-by-Step Deployment

### Step 1 — Create a VPC (Networking Setup)

Set up a Virtual Private Cloud in AWS for network isolation.

- Go to **AWS Console → VPC → Create VPC**
- Region: `us-east-1` (N. Virginia)
- Configure CIDR block: `10.0.0.0/16`

![Step 1 - VPC Dashboard](step1-vpc-dashboard.png)

---

### Step 2 — VPC Successfully Created

The VPC `vpc-0640c3822a6315595` was created successfully with status **Available**.

![Step 2 - VPC Created](step2-vpc-created.png)

---

### Step 3 — Build Website Files in VS Code

Create the static website files locally using VS Code.

**Files created:**
- `index.html` — main portfolio page
- `error.html` — custom error page
- `style.css` — styling

![Step 3 - VS Code Files](step3-vscode-files.png)

---

### Step 4 — Upload Files to S3

1. Go to **AWS Console → S3 → anjum-portfolio-2026 → Upload**
2. Add all 3 files: `index.html`, `error.html`, `style.css`
3. Destination: `s3://anjum-portfolio-2026`
4. Click **Upload**

![Step 4 - S3 Upload](step4-s3-upload.png)

---

### Step 5 — Error Encountered: 403 Forbidden ⚠️

After enabling static website hosting and visiting the S3 URL, a **403 Access Denied** error appeared.

> **Cause:** The S3 bucket did not have a public access policy attached yet.

![Step 5 - 403 Error](step5-errors.png)

---

### Step 6 — Error Encountered: 404 Not Found ⚠️

A second error appeared — **404 NoSuchKey** for `index.html` and `error.html`.

> **Cause:** Files were uploaded inside a subfolder (`aws-static-website/`) rather than at the root of the bucket. Re-uploading files directly to bucket root fixed this.

![Step 6 - 404 Error](step6-errors.png)

---

### Step 7 — Files Successfully Uploaded to S3 ✅

After fixing the upload path, all 3 files appear at the root of the bucket:

| File | Type | Size |
|------|------|------|
| error.html | html | 309 B |
| index.html | html | 2.0 KB |
| style.css | css | 908 B |

![Step 7 - S3 Files Uploaded](step7-s3-uploaded.png)

---

### Step 8 — Enable Static Website Hosting ✅

1. Go to bucket → **Properties** tab
2. Scroll to **Static website hosting** → click **Edit**
3. Select **Enable** → Hosting type: **Host a static website**
4. Index document: `index.html`
5. Error document: `error.html`
6. Click **Save changes**

> ✅ "Successfully edited static website hosting."

![Step 8 - Static Website Hosting Enabled](step8-enabled-static-website.png)

---

### Step 9 — Create CloudFront Distribution ✅

1. Go to **AWS Console → CloudFront → Create Distribution**
2. Origin: select `anjum-portfolio-2026` S3 bucket
3. Viewer protocol policy: `Redirect HTTP to HTTPS`
4. Default root object: `index.html`
5. Click **Create Distribution**

> ✅ "Successfully created new distribution."  
> Distribution domain: `d2wrsh5icek6ta.cloudfront.net`  
> Billing: **Free plan ($0/month)**

![Step 9 - CloudFront Created](step9-cloudfront.png)

---

### Step 10 — CloudFront Distribution Deployed ✅

Wait a few minutes for the distribution status to change from **Deploying** to active.

- Distribution ID: `E1L7BLYL217FTY`
- Domain: `d2wrsh5icek6ta.cloudfront.net`
- Last modified: June 22, 2026

![Step 10 - CloudFront Deployed](step10-deployed.png)

---

### Step 11 — 🎉 Live Portfolio Website

The portfolio is now live and accessible worldwide via CloudFront!

🔗 [https://d2wrsh5icek6ta.cloudfront.net](https://d2wrsh5icek6ta.cloudfront.net)

![Step 11 - Live Site](step11-live-site.png)

---

## 🐛 Errors & Fixes

| Error | Cause | Fix |
|-------|-------|-----|
| **403 Forbidden** | No public bucket policy | Added S3 bucket policy to allow public `GetObject` |
| **404 NoSuchKey** | Files uploaded in subfolder | Re-uploaded files directly to bucket root |

---

## 💡 Tips & Lessons Learned

- Always upload files to the **root** of the S3 bucket, not inside subfolders
- Set the **bucket policy** to allow public read before testing the S3 URL
- CloudFront takes **3–5 minutes** to deploy after creation
- Use CloudFront URL for production — it adds HTTPS and global speed

---

## 👤 Author

**Anjum**  
AWS Cloud Practitioner | Aspiring Cloud Support Engineer  
📍 Dubai, UAE

- GitHub: [@anjum](https://github.com/anjum)
- AWS Account: `289896345323`
